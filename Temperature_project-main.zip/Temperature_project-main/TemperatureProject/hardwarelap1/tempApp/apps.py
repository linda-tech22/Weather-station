from django.apps import AppConfig


class TempappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tempApp'
