# Temperature_project

author : Euro


this webapplication recieves weather data posted on its api endpoint and display that data on the webpage in realtime 
